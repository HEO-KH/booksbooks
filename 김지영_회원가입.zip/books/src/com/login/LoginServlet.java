package com.login;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.DBConn;

public class LoginServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	protected void forward(HttpServletRequest req, HttpServletResponse resp, String url) throws ServletException, IOException {

		RequestDispatcher rd = req.getRequestDispatcher(url);
		rd.forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		req.setCharacterEncoding("UTF-8");

		Connection conn = DBConn.getConnection();
		LoginDAO dao = new LoginDAO(conn);
		String cp = req.getContextPath(); 
		String uri = req.getRequestURI();
		String url;	



		if(uri.indexOf("created.do")!=-1) {

			url = "/create/created.jsp";
			forward(req,resp,url);

		}else if(uri.indexOf("created_ok.do")!=-1) {
			
		

			//�Ѿ�� ������ �ޱ�
			LoginDTO dto = new LoginDTO();
			
			dto.setUserId(req.getParameter("userId"));
			dto.setUserPwd(req.getParameter("userPwd"));
			dto.setUserName(req.getParameter("userName"));
			dto.setUserEmail(req.getParameter("userEmail"));
			dto.setUserBirth(req.getParameter("userBirth"));
			dto.setUserTel(req.getParameter("userTel"));
			dto.setUserNick(req.getParameter("userNick"));
			dto.setGender(req.getParameter("gender"));
			
			dao.insertData(dto);

			url = cp + "/bkJoin/login.do"; //index.jsp�� �̵�*�����ʿ���
			resp.sendRedirect(url);


			}else if(uri.indexOf("login.do")!=-1) { 
			

			url = "/create/login.jsp";
			forward(req, resp, url);

		    }else if(uri.indexOf("login_ok.do")!=-1) {	

			String userId = req.getParameter("userId");
			String userPwd = req.getParameter("userPwd");

			LoginDTO dto = dao.getReadData(userId);

			if(dto==null || (!dto.getUserPwd().equals(userPwd))) { 
				System.out.println(userPwd);
				req.setAttribute("message", "���̵� �Ǵ� �н����带 ��Ȯ�� �Է��ϼ���");				
				req.setAttribute("foundPwd", "��й�ȣ ã��");

				url = "/create/login.jsp";
				forward(req, resp, url);

				return;

			}

			HttpSession session = req.getSession(); 

			CustomInfo info = new CustomInfo();

			info.setUserId(dto.getUserId());		
			info.setUserPwd(dto.getUserPwd());		
			info.setUserName(dto.getUserName());
			info.setUserEmail(dto.getUserEmail());
			info.setUserBirth(dto.getUserBirth());
			info.setUserTel(dto.getUserTel());
			info.setUserNick(dto.getUserNick());
			info.setGender(dto.getGender());

			session.setAttribute("customInfo", info); 

			url = cp + "/bkJoin/update.do";
			resp.sendRedirect(url);

		}else if(uri.indexOf("logout.do")!=-1) {	

			HttpSession session = req.getSession();

			session.removeAttribute("customInfo"); //info�ȿ� �ִ� id�� name�� ����
			session.invalidate(); //���� ��ü�� ����

			url = cp;
			resp.sendRedirect(url);


		}else if(uri.indexOf("pwd.do")!=-1) { //��й�ȣ ã��

			url = "/create/pwd.jsp";
			forward(req, resp, url);

		}else if(uri.indexOf("pwd_ok.do")!=-1) { 	

			String userId = req.getParameter("userId");
			String userTel = req.getParameter("userTel");

			LoginDTO dto = dao.getReadData(userId);

			if(dto==null || (!dto.getUserTel().equals(userTel))) { //���̵� �ۼ����� �ʾҰų� pwd�� ��ġ���� ������

				req.setAttribute("foundMessage", "ȸ�������� �������� �ʽ��ϴ�.");
				req.setAttribute("foundPwd", "��й�ȣ ã��");

				url = "/create/login.jsp";
				forward(req, resp, url);

				return;

			}else {

				req.setAttribute("showPwd", "��й�ȣ�� " + "[" + dto.getUserPwd() + "]" + " �Դϴ�.");

				url = "/create/login.jsp";
				forward(req, resp, url);

				return;

			}	
		}else if(uri.indexOf("update.do")!=-1) {

			String userId = req.getParameter("userId");

			LoginDTO dto = dao.getReadData(userId);

			url = "/create/update.jsp";
			forward(req, resp, url);

		}else if(uri.indexOf("update_ok.do")!=-1) {


			LoginDTO dto = new LoginDTO();

			dto.setUserPwd(req.getParameter("userPwd"));
			dto.setUserNick(req.getParameter("userNick"));
			dto.setUserEmail(req.getParameter("userEmail"));
			dto.setUserTel(req.getParameter("userTel"));
			dto.setUserId(req.getParameter("id"));

			dao.updateData(dto);

			url = cp + "/bkJoin/login.do"; // "index.jsp"�� �̵�
			resp.sendRedirect(url);

		}
	}


}
