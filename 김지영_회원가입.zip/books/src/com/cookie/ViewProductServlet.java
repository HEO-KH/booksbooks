package com.cookie;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ViewProductServlet extends HttpServlet{

	private static final long serialVersionUID = -8772837344399263289L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		String userId = request.getParameter("userId");
		String isbn = request.getParameter("ISBN");

		if (userId != null && isbn != null) {
            // ��Ű�� �ֱ� �� ��ǰ ���� (����ں��� ����)
            String cookieName = "recentProduct_" + userId + "_" + isbn;
            Cookie cookie = new Cookie(cookieName, userId);
            cookie.setMaxAge(60 * 60 * 24); //(60 * 60 * 24) 1�� ���� ��ȿ 3����(100)
            cookie.setPath("/"); //��𼭵� ���� ����
            response.addCookie(cookie);
        }
		

        // ��ǰ �������� �̵� (��: product.jsp)
		request.getRequestDispatcher("https://product.kyobobook.co.kr/detail/S000001913217").forward(request, response);

	}
	
	

	
}
